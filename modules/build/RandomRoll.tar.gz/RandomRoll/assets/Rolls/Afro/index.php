
<html>
<head>
	<title>Afro Circus Afro Circus Afro Circus Afro Circus</title>
</head>

<body bgcolor="#0C31C4">
<center>
	<img src="Rolls/Afro/asset/gif.gif" />
</center>
 <audio loop autoplay>
 	 <source src="Rolls/Afro/asset/song.mp3" type="audio/mpeg">
  	 <source src="Rolls/Afro/asset/.ogg" type="audio/ogg">
 </audio>
</body>

<!-- Foxtrot, sebkinne -->