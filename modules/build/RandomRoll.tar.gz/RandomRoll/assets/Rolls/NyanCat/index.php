<HTML>
<head>
  <!-- NyanRoll by Foxtrot -->
<title>Nyan Nyan Nyan Nyan Ny-argh give it a rest.</title> 
</head> 
<body bgcolor="blue">
<center>
<img src="Rolls/NyanCat/asset/gif.gif">	
</center>

 <audio loop autoplay>
 	 <source src="Rolls/NyanCat/asset/song.mp3" type="audio/mpeg">
  	 <source src="Rolls/NyanCat/asset/song.ogg" type="audio/ogg">
 </audio>


</body>
</HTML>
