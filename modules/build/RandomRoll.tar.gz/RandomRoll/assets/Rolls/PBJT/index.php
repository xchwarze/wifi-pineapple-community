<HTML>
<head>
	<!-- PBJTRoll for RandomRoll     Created by Foxtrot -->

<title>PEANUT BUTTER JELLY    PEANUT BUTTER JELLY    PEANUT BUTTER JELLY</title> 
</head> 
<body bgcolor="yellow">
<center>
	<img src="Rolls/PBJT/asset/gif.gif">

  <audio loop autoplay>
 	 <source src="Rolls/PBJT/asset/song.mp3" type="audio/mpeg">
  	 <source src="Rolls/PBJT/asset/song.ogg" type="audio/ogg">
 </audio>
 </center>

</body>
</HTML>
