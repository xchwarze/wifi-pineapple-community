
<html>
<head>
    <title>0x800000300000600000</title>
    <style type="text/css">
    body {
    background:#0000aa;
    color:#ffffff;
    font-family:courier;
    font-size:12pt;
    text-align:center;
    margin:100px;
    font-style:bold;
}

blink {
    color:yellow;
}

.neg {
    background:#fff;
    color:#0000aa;
    padding:2px 8px;
    font-weight:bold;
}

p {
    margin:30px 100px;
    text-align:left;
}

a,a:hover {
    color:inherit;
    font:inherit;
}

.menu {
    text-align:center;
    margin-top:50px;
}
    </style>
</head>

<body>
    <center>
        <span class="neg">WINDOWS</span>
        <p>
An exception 06 has occured at 0028:C11B3ADC in  VxD DiskTSD(03) +<br />
00001660. This was called from 0028:C11B40CB in VxD  voltrack(04) +<br />
00000000. It may be possible to continue normally.
        </p>

        <p>
* Press any key to attempt to continue.<br />

* Press CTRL+ALT+DEL to restart your computer. You will<br />
 &nbsp; lose unsaved information in any programs that are running.
        </p>
Press any key to continue<img src="Rolls/BSOD/asset/bsodknipper.gif" name="knipper" />
</center>

 <audio loop autoplay>
     <source src="Rolls/BSOD/asset/song.mp3" type="audio/mpeg">
     <source src="Rolls/BSOD/asset/song.ogg" type="audio/ogg">
 </audio>

</body>

</html>