<HTML>
<head>

<title>Troll lol lol lolllll!!</title> 
</head>
<body>
<body bgcolor="black">
<center>
	<img src="Rolls/Troll/asset/gif.gif">

 <audio loop autoplay>
 	 <source src="Rolls/Troll/asset/song.mp3" type="audio/mpeg">
  	 <source src="Rolls/Troll/asset/song.ogg" type="audio/ogg">
 </audio>


</body>
</HTML>
