#!/bin/sh

#  Author: sud0nick
#  Date:   Jan 2016

opkg update > /dev/null;
opkg install zip > /dev/null;
echo "Complete"
